'''Capture global config'''

if not "config" in globals():
    config = {}
