import logging

logging.disable(logging.ERROR)
